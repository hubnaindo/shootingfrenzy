const express = require("express");
const http = require("http");
const path = require("path");
const { WebSocketServer } = require("ws");
const MAPS = require("./public/maps.js");
const { WEAPONS, PRIMARY_CHOICES, SECONDARY_CHOICES } = require("./public/weapons.js");

const PORT = process.env.PORT || 3000;
const TICK_MS = 33; // ~30 updates/sec
const ROUND_MS = 10 * 60 * 1000; // 10 minutes
const INTERMISSION_MS = 12 * 1000; // leaderboard screen between rounds
const PLAYER_RADIUS = 18;
const PLAYER_MAX_HP = 100;
const MOVE_SPEED_CAP = 320; // world units/sec, used to sanity-clamp reported movement

const app = express();
app.use(express.static(path.join(__dirname, "public")));
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

/** @type {Map<string, Player>} */
const players = new Map();

let state = "INTERMISSION"; // "ACTIVE" | "INTERMISSION"
let currentMap = pickMap(null);
let roundEndAt = 0;
let intermissionEndAt = Date.now() + 3000;
let lastLeaderboard = [];

function pickMap(excludeId) {
  const pool = excludeId ? MAPS.filter((m) => m.id !== excludeId) : MAPS;
  return pool[Math.floor(Math.random() * pool.length)];
}

function randomSpawn() {
  const s = currentMap.spawns[Math.floor(Math.random() * currentMap.spawns.length)];
  return { x: s.x, y: s.y };
}

function makeLoadoutAmmo(primaryId, secondaryId) {
  return {
    [primaryId]: WEAPONS[primaryId].mag,
    [secondaryId]: WEAPONS[secondaryId].mag,
  };
}

class Player {
  constructor(id, ws) {
    this.id = id;
    this.ws = ws;
    this.name = "Recruit";
    this.primary = "rifle";
    this.secondary = "pistol";
    this.joined = false; // has sent a valid "join" and is participating this round or queued
    this.alive = false;
    this.spectating = true;
    this.x = 0;
    this.y = 0;
    this.angle = 0;
    this.hp = PLAYER_MAX_HP;
    this.kills = 0;
    this.deaths = 0;
    this.currentWeapon = "rifle";
    this.ammo = {};
    this.reloading = false;
    this.lastShotAt = 0;
    this.lastInputAt = Date.now();
  }
}

function send(ws, type, data) {
  if (ws.readyState === ws.OPEN) {
    try { ws.send(JSON.stringify({ type, ...data })); } catch (e) { /* ignore */ }
  }
}

function broadcast(type, data, filterFn) {
  const payload = JSON.stringify({ type, ...data });
  for (const p of players.values()) {
    if (filterFn && !filterFn(p)) continue;
    if (p.ws.readyState === p.ws.OPEN) p.ws.send(payload);
  }
}

function publicPlayer(p) {
  return {
    id: p.id, name: p.name, x: p.x, y: p.y, angle: p.angle,
    hp: p.hp, alive: p.alive, kills: p.kills, deaths: p.deaths,
    weapon: p.currentWeapon,
  };
}

function startRound() {
  currentMap = pickMap(currentMap ? currentMap.id : null);
  state = "ACTIVE";
  roundEndAt = Date.now() + ROUND_MS;
  for (const p of players.values()) {
    if (!p.joined) continue;
    p.kills = 0;
    p.deaths = 0;
    p.hp = PLAYER_MAX_HP;
    p.alive = true;
    p.spectating = false;
    p.reloading = false;
    p.currentWeapon = p.primary;
    p.ammo = makeLoadoutAmmo(p.primary, p.secondary);
    const sp = randomSpawn();
    p.x = sp.x; p.y = sp.y; p.angle = 0;
  }
  broadcast("roundStart", {
    map: { id: currentMap.id, name: currentMap.name, theme: currentMap.theme, width: currentMap.width, height: currentMap.height, obstacles: currentMap.obstacles, bg: currentMap.bg, accent: currentMap.accent },
    endAt: roundEndAt,
    players: [...players.values()].filter((p) => p.joined).map(publicPlayer),
  });
}

function endRound() {
  state = "INTERMISSION";
  intermissionEndAt = Date.now() + INTERMISSION_MS;
  lastLeaderboard = [...players.values()]
    .filter((p) => p.joined)
    .map((p) => ({ id: p.id, name: p.name, kills: p.kills, deaths: p.deaths }))
    .sort((a, b) => b.kills - a.kills);
  for (const p of players.values()) {
    p.alive = false;
    p.spectating = true;
  }
  broadcast("roundEnd", { leaderboard: lastLeaderboard, nextRoundAt: intermissionEndAt });
}

function killPlayer(victim, killerId, weaponId) {
  victim.alive = false;
  victim.spectating = true;
  victim.deaths += 1;
  victim.hp = 0;
  const killer = killerId ? players.get(killerId) : null;
  if (killer && killer !== victim) killer.kills += 1;
  broadcast("kill", {
    victim: victim.id, victimName: victim.name,
    killer: killer ? killer.id : null, killerName: killer ? killer.name : "the arena",
    weapon: weaponId || null,
  });
  send(victim.ws, "youDied", { respawnWaitMs: 30000, killerName: killer ? killer.name : "the arena" });
}

function rectCircleBlocked(map, x, y, r) {
  if (x - r < 0 || y - r < 0 || x + r > map.width || y + r > map.height) return true;
  for (const o of map.obstacles) {
    const cx = Math.max(o.x, Math.min(x, o.x + o.w));
    const cy = Math.max(o.y, Math.min(y, o.y + o.h));
    const dx = x - cx, dy = y - cy;
    if (dx * dx + dy * dy < r * r) return true;
  }
  return false;
}

function segmentIntersectsRect(x1, y1, x2, y2, r) {
  // Basic AABB vs segment overlap test using sampling (cheap, arena is small obstacle count).
  const steps = 24;
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const px = x1 + (x2 - x1) * t;
    const py = y1 + (y2 - y1) * t;
    for (const o of r) {
      if (px >= o.x && px <= o.x + o.w && py >= o.y && py <= o.y + o.h) return true;
    }
  }
  return false;
}

wss.on("connection", (ws) => {
  const id = Math.random().toString(36).slice(2, 10);
  const player = new Player(id, ws);
  players.set(id, player);
  send(ws, "welcome", { id, weapons: WEAPONS, primaryChoices: PRIMARY_CHOICES, secondaryChoices: SECONDARY_CHOICES });

  ws.on("message", (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch (e) { return; }
    if (!msg || typeof msg.type !== "string") return;

    switch (msg.type) {
      case "join": {
        const name = (typeof msg.name === "string" ? msg.name.trim() : "").slice(0, 16) || "Recruit";
        const primary = PRIMARY_CHOICES.includes(msg.primary) ? msg.primary : "rifle";
        const secondary = SECONDARY_CHOICES.includes(msg.secondary) ? msg.secondary : "pistol";
        player.name = name;
        player.primary = primary;
        player.secondary = secondary;
        player.joined = true;

        if (state === "ACTIVE") {
          player.alive = true;
          player.spectating = false;
          player.hp = PLAYER_MAX_HP;
          player.kills = 0;
          player.deaths = 0;
          player.currentWeapon = primary;
          player.ammo = makeLoadoutAmmo(primary, secondary);
          const sp = randomSpawn();
          player.x = sp.x; player.y = sp.y; player.angle = 0;
          send(ws, "roundStart", {
            map: { id: currentMap.id, name: currentMap.name, theme: currentMap.theme, width: currentMap.width, height: currentMap.height, obstacles: currentMap.obstacles, bg: currentMap.bg, accent: currentMap.accent },
            endAt: roundEndAt,
            players: [...players.values()].filter((p) => p.joined).map(publicPlayer),
          });
          broadcast("playerJoined", { player: publicPlayer(player) }, (p) => p.id !== player.id);
        } else {
          player.alive = false;
          player.spectating = true;
          send(ws, "queued", { nextRoundAt: intermissionEndAt, leaderboard: lastLeaderboard });
        }
        break;
      }
      case "input": {
        if (!player.alive) return;
        const now = Date.now();
        const dt = Math.min(0.12, (now - player.lastInputAt) / 1000);
        player.lastInputAt = now;
        if (typeof msg.angle === "number") player.angle = msg.angle;
        if (typeof msg.dx === "number" && typeof msg.dy === "number") {
          let mag = Math.hypot(msg.dx, msg.dy);
          const nx = mag > 1 ? msg.dx / mag : msg.dx;
          const ny = mag > 1 ? msg.dy / mag : msg.dy;
          const maxStep = MOVE_SPEED_CAP * dt;
          const targetX = player.x + nx * maxStep;
          const targetY = player.y + ny * maxStep;
          if (!rectCircleBlocked(currentMap, targetX, player.y, PLAYER_RADIUS)) player.x = targetX;
          if (!rectCircleBlocked(currentMap, player.x, targetY, PLAYER_RADIUS)) player.y = targetY;
        }
        break;
      }
      case "switchWeapon": {
        if (!player.alive || player.reloading) return;
        if (msg.weapon === "primary") player.currentWeapon = player.primary;
        else if (msg.weapon === "secondary") player.currentWeapon = player.secondary;
        break;
      }
      case "reload": {
        if (!player.alive || player.reloading) return;
        const w = WEAPONS[player.currentWeapon];
        if (player.ammo[player.currentWeapon] >= w.mag) return;
        player.reloading = true;
        send(ws, "reloading", { weapon: player.currentWeapon, time: w.reloadTime });
        setTimeout(() => {
          if (!players.has(id)) return;
          player.ammo[player.currentWeapon] = w.mag;
          player.reloading = false;
          send(ws, "reloaded", { weapon: player.currentWeapon });
        }, w.reloadTime);
        break;
      }
      case "shoot": {
        if (!player.alive || player.reloading || state !== "ACTIVE") return;
        const w = WEAPONS[player.currentWeapon];
        const now = Date.now();
        if (now - player.lastShotAt < w.fireRate) return;
        if ((player.ammo[player.currentWeapon] || 0) <= 0) return;
        player.lastShotAt = now;
        player.ammo[player.currentWeapon] -= 1;
        const baseAngle = typeof msg.angle === "number" ? msg.angle : player.angle;
        broadcast("shotFired", { by: player.id, angle: baseAngle, weapon: player.currentWeapon });

        for (let i = 0; i < w.pellets; i++) {
          const spreadAngle = baseAngle + (Math.random() * 2 - 1) * w.spread;
          const dx = Math.cos(spreadAngle), dy = Math.sin(spreadAngle);
          let closest = null;
          let closestDist = w.range;
          for (const other of players.values()) {
            if (other.id === player.id || !other.alive) continue;
            const relx = other.x - player.x, rely = other.y - player.y;
            const proj = relx * dx + rely * dy;
            if (proj < 0 || proj > w.range) continue;
            const perpx = relx - dx * proj, perpy = rely - dy * proj;
            const perpDist = Math.hypot(perpx, perpy);
            if (perpDist > PLAYER_RADIUS + 4) continue;
            if (segmentIntersectsRect(player.x, player.y, player.x + dx * proj, player.y + dy * proj, currentMap.obstacles)) continue;
            if (proj < closestDist) { closestDist = proj; closest = other; }
          }
          if (closest) {
            closest.hp -= w.damage;
            send(closest.ws, "damaged", { hp: Math.max(0, closest.hp), by: player.name });
            if (closest.hp <= 0) {
              killPlayer(closest, player.id, w.id);
              break;
            }
          }
        }
        break;
      }
      default:
        break;
    }
  });

  ws.on("close", () => {
    players.delete(id);
    broadcast("playerLeft", { id });
  });
});

setInterval(() => {
  const now = Date.now();
  if (state === "ACTIVE" && now >= roundEndAt) {
    endRound();
  } else if (state === "INTERMISSION" && now >= intermissionEndAt) {
    startRound();
  }
  if (state === "ACTIVE") {
    broadcast("state", {
      t: now,
      endAt: roundEndAt,
      players: [...players.values()].filter((p) => p.joined).map(publicPlayer),
    });
  }
}, TICK_MS);

server.listen(PORT, () => {
  console.log(`Shooter server running on http://localhost:${PORT}`);
});
