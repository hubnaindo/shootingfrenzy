# Vector Front — Multiplayer Shooter

A top-down, browser-based multiplayer shooter with **one authoritative Node.js server**,
**mobile touch controls** (dual virtual joysticks) and **PC controls** (WASD + mouse),
a loadout customizer, 5 randomly-rotating maps, 10-minute rounds, a kill leaderboard,
and a 30-second "back to the loading screen" respawn wait.

## How it works

- **Server** (`server.js`): a single Node process using `express` (static file hosting)
  and `ws` (WebSockets). It is authoritative for hit detection, damage, kills, deaths,
  round timing and map selection, so all connected players — phones, tablets, laptops,
  desktops — play in the same match on equal footing.
- **Client** (`public/`): plain HTML/CSS/JS (no build step). It auto-detects touch
  support and swaps in virtual joysticks + action buttons for mobile, or WASD/mouse
  hints for PC/trackpad. Rendering is a 2D top-down canvas view centered on the player.

## Run it

Requires [Node.js](https://nodejs.org) 18+.

```bash
cd shooter-game
npm install
npm start
```

Then open **http://localhost:3000** in a browser. To test multiplayer, open it in a
second browser tab/window (or from another device on the same Wi-Fi using your
computer's local IP, e.g. `http://192.168.1.23:3000`) — every client connects to the
same server and the same live match.

Opening the project in VS Code: `File → Open Folder…` → select `shooter-game`, then
use the built-in terminal (`` Ctrl+` ``) to run the two commands above.

## Game flow

1. **Loading screen** — enter a callsign, pick **one primary** (Assault Rifle, SMG or
   Shotgun) and **one secondary** (Pistol or Revolver), then hit **PLAY**.
2. **Match** — you drop into whichever of the 5 maps is active (chosen at random each
   round): Dust Outpost, Downtown Grid, Frostbite Ridge, Jungle Ruins, Warehouse
   District. Each round runs for **10 minutes**. Kill feed, health, ammo and the round
   timer are shown in the HUD.
3. **Death** — you're taken to an "Eliminated" screen with a **30-second** countdown,
   then automatically returned to the loading screen to rejoin.
4. **Round end** — when the 10-minute timer runs out, everyone sees a **leaderboard**
   ranked by kills (with deaths shown too), then the loading screen reappears while
   the server picks the next random map and starts the next round.

## Controls

- **PC**: `W A S D` to move, mouse to aim, left click to fire (auto-fires at the
  weapon's rate while held), `R` to reload, `Q` to swap primary/secondary.
- **Mobile**: left joystick to move, right joystick to aim + fire (drag it out past
  the dead-zone to shoot in that direction), plus on-screen **RELOAD** and **SWAP**
  buttons.

## Project structure

```
shooter-game/
├── server.js          # authoritative game server (rounds, hit detection, matchmaking)
├── package.json
├── public/
│   ├── index.html      # menu, HUD, death & leaderboard screens
│   ├── style.css        # tactical-HUD visual design
│   ├── game.js           # client networking, rendering, PC + mobile input
│   ├── maps.js            # the 5 map layouts (shared by server & client)
│   └── weapons.js          # weapon stats & loadout choices (shared)
└── README.md
```

## Notes / things you may want to improvise further

- Hit detection is server-side hitscan (instant-travel bullets with a spread cone),
  not simulated projectiles — this keeps the netcode simple and fair across
  high-ping mobile connections.
- Movement is client-reported and server-clamped to map bounds/obstacles; it's not a
  full lag-compensated authoritative simulation, which is normally fine for a casual
  arena shooter but wouldn't hold up against a determined cheater.
- There's currently no lobby cap, teams, or ranked matchmaking — every connected
  player is dropped into the same room. Splitting into multiple rooms/servers is the
  natural next step if you want larger player counts.
