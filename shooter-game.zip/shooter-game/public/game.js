(() => {
  "use strict";

  // ---------- DOM ----------
  const screens = {
    menu: document.getElementById("screen-menu"),
    death: document.getElementById("screen-death"),
    game: document.getElementById("screen-game"),
  };
  const connDot = document.getElementById("conn-dot");
  const connText = document.getElementById("conn-text");
  const roundInfoRow = document.getElementById("round-info-row");
  const roundInfoText = document.getElementById("round-info-text");
  const nameInput = document.getElementById("name-input");
  const primaryGrid = document.getElementById("primary-grid");
  const secondaryGrid = document.getElementById("secondary-grid");
  const playBtn = document.getElementById("play-btn");
  const leaderboardPanel = document.getElementById("leaderboard-panel");
  const leaderboardList = document.getElementById("leaderboard-list");

  const deathSub = document.getElementById("death-sub");
  const deathTimerEl = document.getElementById("death-timer");

  const canvas = document.getElementById("game-canvas");
  const ctx = canvas.getContext("2d");
  const hudTimer = document.getElementById("hud-timer");
  const hudMap = document.getElementById("hud-map");
  const hudKillfeed = document.getElementById("hud-killfeed");
  const hudHealthFill = document.getElementById("hud-health-fill");
  const hudHealthLabel = document.getElementById("hud-health-label");
  const hudWeaponName = document.getElementById("hud-weapon-name");
  const hudAmmoCount = document.getElementById("hud-ammo-count");
  const pcHint = document.getElementById("pc-hint");
  const mobileControls = document.getElementById("mobile-controls");
  const joyMove = document.getElementById("joy-move");
  const joyMoveNub = document.getElementById("joy-move-nub");
  const joyFire = document.getElementById("joy-fire");
  const joyFireNub = document.getElementById("joy-fire-nub");
  const btnReload = document.getElementById("btn-reload");
  const btnSwap = document.getElementById("btn-swap");

  const IS_TOUCH = ("ontouchstart" in window) || navigator.maxTouchPoints > 0;

  // ---------- Local state ----------
  let ws = null;
  let selfId = null;
  let selectedPrimary = "rifle";
  let selectedSecondary = "pistol";
  let hasJoined = false;

  let currentMap = null;      // {id,name,theme,width,height,obstacles,bg,accent}
  let roundEndAt = 0;
  let remotePlayers = new Map(); // id -> latest server snapshot
  let self = { x: 0, y: 0, angle: 0, hp: 100, alive: false, weapon: "rifle" };
  let ammoLocal = {};          // client-predicted ammo for instant HUD feedback
  let reloading = false;
  let tracers = [];            // transient visual bullet lines {x1,y1,x2,y2,life}

  let deathCountdownHandle = null;

  // ---------- Screen management ----------
  function showScreen(name) {
    for (const key of Object.keys(screens)) screens[key].hidden = key !== name;
  }

  // ---------- Weapon selection UI ----------
  function buildWeaponGrid(container, choices, selectedRef, onPick) {
    container.innerHTML = "";
    choices.forEach((wid) => {
      const w = WEAPONS[wid];
      const card = document.createElement("div");
      card.className = "weapon-card" + (wid === selectedRef.value ? " selected" : "");
      card.innerHTML = `<div class="wname">${w.name}</div><div class="wstats">DMG ${w.damage} · MAG ${w.mag} · RNG ${w.range}</div>`;
      card.addEventListener("click", () => {
        selectedRef.value = wid;
        [...container.children].forEach((c) => c.classList.remove("selected"));
        card.classList.add("selected");
        onPick(wid);
      });
      container.appendChild(card);
    });
  }

  function initMenu() {
    const primaryRef = { value: selectedPrimary };
    const secondaryRef = { value: selectedSecondary };
    buildWeaponGrid(primaryGrid, PRIMARY_CHOICES, primaryRef, (wid) => (selectedPrimary = wid));
    buildWeaponGrid(secondaryGrid, SECONDARY_CHOICES, secondaryRef, (wid) => (selectedSecondary = wid));
    nameInput.value = "Recruit" + Math.floor(Math.random() * 900 + 100);
  }

  function renderLeaderboard(list) {
    if (!list || !list.length) { leaderboardPanel.hidden = true; return; }
    leaderboardPanel.hidden = false;
    leaderboardList.innerHTML = "";
    list.forEach((p, i) => {
      const li = document.createElement("li");
      li.innerHTML = `<span class="rank">#${i + 1}</span><span class="lname">${escapeHtml(p.name)}</span><span class="lkills">${p.kills} kills · ${p.deaths} deaths</span>`;
      leaderboardList.appendChild(li);
    });
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  // ---------- Networking ----------
  function connect() {
    const proto = location.protocol === "https:" ? "wss" : "ws";
    ws = new WebSocket(`${proto}://${location.host}`);

    ws.addEventListener("open", () => {
      connDot.classList.add("ok");
      connText.textContent = "connected — ready to deploy";
      playBtn.disabled = false;
      playBtn.querySelector(".play-btn-label").textContent = "PLAY";
    });

    ws.addEventListener("close", () => {
      connDot.classList.remove("ok");
      connText.textContent = "disconnected — retrying…";
      playBtn.disabled = true;
      playBtn.querySelector(".play-btn-label").textContent = "RECONNECTING…";
      setTimeout(connect, 1500);
    });

    ws.addEventListener("error", () => ws.close());

    ws.addEventListener("message", (evt) => {
      let msg;
      try { msg = JSON.parse(evt.data); } catch (e) { return; }
      handleServerMessage(msg);
    });
  }

  function sendMsg(type, data) {
    if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type, ...data }));
  }

  function handleServerMessage(msg) {
    switch (msg.type) {
      case "welcome":
        selfId = msg.id;
        break;

      case "queued":
        hasJoined = true;
        clearDeathCountdown();
        showScreen("menu");
        roundInfoRow.hidden = false;
        roundInfoText.textContent = "match in progress — you're queued for the next round";
        renderLeaderboard(msg.leaderboard);
        break;

      case "roundStart":
        clearDeathCountdown();
        currentMap = msg.map;
        roundEndAt = msg.endAt;
        remotePlayers = new Map(msg.players.map((p) => [p.id, p]));
        const me = remotePlayers.get(selfId);
        if (me) { self.x = me.x; self.y = me.y; self.hp = me.hp; self.alive = true; self.weapon = me.weapon; }
        ammoLocal = { [selectedPrimary]: WEAPONS[selectedPrimary].mag, [selectedSecondary]: WEAPONS[selectedSecondary].mag };
        reloading = false;
        hudMap.textContent = currentMap.name;
        showScreen("game");
        resizeCanvas();
        break;

      case "state":
        roundEndAt = msg.endAt;
        remotePlayers = new Map(msg.players.map((p) => [p.id, p]));
        const meNow = remotePlayers.get(selfId);
        if (meNow && self.alive) { self.x = meNow.x; self.y = meNow.y; self.hp = meNow.hp; }
        break;

      case "shotFired":
        spawnTracerFor(msg.by, msg.angle, msg.weapon);
        break;

      case "damaged":
        self.hp = msg.hp;
        break;

      case "kill":
        pushKillfeed(msg);
        break;

      case "reloading":
        reloading = true;
        break;

      case "reloaded":
        reloading = false;
        ammoLocal[msg.weapon] = WEAPONS[msg.weapon].mag;
        break;

      case "youDied":
        self.alive = false;
        enterDeathScreen(msg.killerName, msg.respawnWaitMs || 30000);
        break;

      case "roundEnd":
        self.alive = false;
        clearDeathCountdown();
        showScreen("menu");
        roundInfoRow.hidden = false;
        roundInfoText.textContent = "round complete — next round starting soon";
        renderLeaderboard(msg.leaderboard);
        break;

      case "playerJoined":
        remotePlayers.set(msg.player.id, msg.player);
        break;

      case "playerLeft":
        remotePlayers.delete(msg.id);
        break;

      default:
        break;
    }
  }

  // ---------- Play button ----------
  playBtn.addEventListener("click", () => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    const name = nameInput.value.trim() || "Recruit";
    sendMsg("join", { name, primary: selectedPrimary, secondary: selectedSecondary });
    playBtn.disabled = true;
    playBtn.querySelector(".play-btn-label").textContent = "DEPLOYING…";
    setTimeout(() => { if (playBtn.disabled) playBtn.disabled = false; playBtn.querySelector(".play-btn-label").textContent = "PLAY"; }, 4000);
  });

  // ---------- Death screen ----------
  function clearDeathCountdown() {
    if (deathCountdownHandle) { clearInterval(deathCountdownHandle); deathCountdownHandle = null; }
  }
  function enterDeathScreen(killerName, waitMs) {
    showScreen("death");
    deathSub.textContent = killerName ? `eliminated by ${killerName}` : "eliminated";
    let remaining = Math.ceil(waitMs / 1000);
    deathTimerEl.textContent = remaining;
    clearDeathCountdown();
    deathCountdownHandle = setInterval(() => {
      remaining -= 1;
      deathTimerEl.textContent = Math.max(0, remaining);
      if (remaining <= 0) {
        clearDeathCountdown();
        roundInfoRow.hidden = true;
        showScreen("menu");
        playBtn.disabled = false;
        playBtn.querySelector(".play-btn-label").textContent = "PLAY";
      }
    }, 1000);
  }

  // ---------- Kill feed ----------
  function pushKillfeed(msg) {
    const div = document.createElement("div");
    div.className = "kf-item";
    const weaponName = msg.weapon && WEAPONS[msg.weapon] ? WEAPONS[msg.weapon].name : "";
    div.textContent = msg.killer ? `${msg.killerName} ↦ ${msg.victimName}  [${weaponName}]` : `${msg.victimName} died`;
    hudKillfeed.appendChild(div);
    setTimeout(() => div.remove(), 6000);
    while (hudKillfeed.children.length > 5) hudKillfeed.removeChild(hudKillfeed.firstChild);
  }

  // ---------- Tracers (visual only) ----------
  function spawnTracerFor(byId, angle, weaponId) {
    const shooter = byId === selfId ? self : remotePlayers.get(byId);
    if (!shooter) return;
    const w = WEAPONS[weaponId];
    const x1 = shooter.x, y1 = shooter.y;
    const x2 = x1 + Math.cos(angle) * w.range;
    const y2 = y1 + Math.sin(angle) * w.range;
    tracers.push({ x1, y1, x2, y2, life: 1 });
  }

  // ---------- Canvas sizing ----------
  function resizeCanvas() {
    canvas.width = window.innerWidth * devicePixelRatio;
    canvas.height = window.innerHeight * devicePixelRatio;
    canvas.style.width = window.innerWidth + "px";
    canvas.style.height = window.innerHeight + "px";
  }
  window.addEventListener("resize", resizeCanvas);

  // ---------- Input: PC ----------
  const keys = { w: false, a: false, s: false, d: false };
  let mouseAngle = 0;
  let mouseDown = false;
  let fireHeld = false;
  let fireLoopHandle = null;

  window.addEventListener("keydown", (e) => {
    const k = e.key.toLowerCase();
    if (k in keys) keys[k] = true;
    if (k === "r") sendMsg("reload", {});
    if (k === "q") { self.weapon = self.weapon === selectedPrimary ? selectedSecondary : selectedPrimary; sendMsg("switchWeapon", { weapon: self.weapon === selectedPrimary ? "primary" : "secondary" }); }
  });
  window.addEventListener("keyup", (e) => {
    const k = e.key.toLowerCase();
    if (k in keys) keys[k] = false;
  });

  canvas.addEventListener("mousemove", (e) => {
    if (IS_TOUCH) return;
    const rect = canvas.getBoundingClientRect();
    const cx = rect.width / 2, cy = rect.height / 2;
    mouseAngle = Math.atan2(e.clientY - rect.top - cy, e.clientX - rect.left - cx);
  });
  canvas.addEventListener("mousedown", () => { mouseDown = true; startFireLoop(WEAPONS[self.weapon] ? WEAPONS[self.weapon].fireRate : 150); });
  window.addEventListener("mouseup", () => { mouseDown = false; stopFireLoop(); });

  function startFireLoop(rate) {
    if (IS_TOUCH) return;
    stopFireLoop();
    doFireAttempt();
    fireLoopHandle = setInterval(doFireAttempt, Math.max(60, rate));
  }
  function stopFireLoop() {
    if (fireLoopHandle) { clearInterval(fireLoopHandle); fireLoopHandle = null; }
  }
  function doFireAttempt() {
    if (!self.alive || reloading) return;
    const key = self.weapon;
    if ((ammoLocal[key] ?? 0) <= 0) return;
    ammoLocal[key] -= 1;
    sendMsg("shoot", { angle: self.angle });
  }

  // ---------- Input: Mobile joysticks ----------
  const moveVec = { x: 0, y: 0 };
  let fireVec = { x: 0, y: 0, active: false };

  function setupJoystick(el, nub, onMove, onEnd) {
    let touchId = null;
    const rect = () => el.getBoundingClientRect();

    function start(e) {
      const t = e.changedTouches ? e.changedTouches[0] : e;
      touchId = t.identifier ?? "mouse";
      handle(t);
      e.preventDefault();
    }
    function handle(t) {
      const r = rect();
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      let dx = t.clientX - cx, dy = t.clientY - cy;
      const max = r.width / 2;
      const dist = Math.hypot(dx, dy);
      if (dist > max) { dx = (dx / dist) * max; dy = (dy / dist) * max; }
      nub.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
      onMove(dx / max, dy / max);
    }
    function move(e) {
      if (touchId === null) return;
      const t = e.changedTouches ? [...e.changedTouches].find((x) => x.identifier === touchId) : e;
      if (!t) return;
      handle(t);
      e.preventDefault();
    }
    function end(e) {
      if (touchId === null) return;
      touchId = null;
      nub.style.transform = "translate(-50%, -50%)";
      onEnd();
    }
    el.addEventListener("touchstart", start, { passive: false });
    el.addEventListener("touchmove", move, { passive: false });
    el.addEventListener("touchend", end);
    el.addEventListener("touchcancel", end);
  }

  if (IS_TOUCH) {
    setupJoystick(joyMove, joyMoveNub, (nx, ny) => { moveVec.x = nx; moveVec.y = ny; }, () => { moveVec.x = 0; moveVec.y = 0; });
    setupJoystick(joyFire, joyFireNub, (nx, ny) => {
      fireVec = { x: nx, y: ny, active: Math.hypot(nx, ny) > 0.25 };
      if (fireVec.active) self.angle = Math.atan2(ny, nx);
    }, () => { fireVec = { x: 0, y: 0, active: false }; });

    btnReload.addEventListener("click", () => sendMsg("reload", {}));
    btnSwap.addEventListener("click", () => {
      self.weapon = self.weapon === selectedPrimary ? selectedSecondary : selectedPrimary;
      sendMsg("switchWeapon", { weapon: self.weapon === selectedPrimary ? "primary" : "secondary" });
    });
  }

  function applyControlVisibility() {
    if (IS_TOUCH) {
      mobileControls.hidden = false;
      pcHint.hidden = true;
    } else {
      mobileControls.hidden = true;
      pcHint.hidden = false;
    }
  }

  // ---------- Main loop ----------
  let lastFireSentAt = 0;
  function tick() {
    if (!screens.game.hidden && self.alive) {
      // movement
      let dx = 0, dy = 0;
      if (IS_TOUCH) {
        dx = moveVec.x; dy = moveVec.y;
      } else {
        if (keys.w) dy -= 1;
        if (keys.s) dy += 1;
        if (keys.a) dx -= 1;
        if (keys.d) dx += 1;
        const mag = Math.hypot(dx, dy);
        if (mag > 0) { dx /= mag; dy /= mag; }
        self.angle = mouseAngle;
      }
      if (IS_TOUCH) {
        if (fireVec.active) self.angle = Math.atan2(fireVec.y, fireVec.x);
      }
      sendMsg("input", { dx, dy, angle: self.angle });

      // mobile auto-fire while fire-stick held
      if (IS_TOUCH && fireVec.active && !reloading) {
        const now = performance.now();
        const w = WEAPONS[self.weapon] || WEAPONS.rifle;
        const key = self.weapon;
        if (now - lastFireSentAt > w.fireRate && (ammoLocal[key] ?? 0) > 0) {
          lastFireSentAt = now;
          ammoLocal[key] -= 1;
          sendMsg("shoot", { angle: self.angle });
        }
      }
    }

    render();
    requestAnimationFrame(tick);
  }

  function render() {
    if (screens.game.hidden || !currentMap) return;
    const w = canvas.width, h = canvas.height;
    ctx.save();
    ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
    ctx.fillStyle = currentMap.bg || "#111";
    ctx.fillRect(0, 0, w / devicePixelRatio, h / devicePixelRatio);

    const viewW = window.innerWidth, viewH = window.innerHeight;
    const camX = self.x - viewW / 2, camY = self.y - viewH / 2;

    ctx.save();
    ctx.translate(-camX, -camY);

    // ground grid
    ctx.strokeStyle = "rgba(255,255,255,0.04)";
    ctx.lineWidth = 1;
    const gridSize = 100;
    const startX = Math.floor(camX / gridSize) * gridSize;
    const startY = Math.floor(camY / gridSize) * gridSize;
    for (let x = startX; x < camX + viewW + gridSize; x += gridSize) {
      ctx.beginPath(); ctx.moveTo(x, camY); ctx.lineTo(x, camY + viewH); ctx.stroke();
    }
    for (let y = startY; y < camY + viewH + gridSize; y += gridSize) {
      ctx.beginPath(); ctx.moveTo(camX, y); ctx.lineTo(camX + viewW, y); ctx.stroke();
    }

    // map bounds
    ctx.strokeStyle = currentMap.accent || "#888";
    ctx.lineWidth = 4;
    ctx.strokeRect(0, 0, currentMap.width, currentMap.height);

    // obstacles
    ctx.fillStyle = "rgba(0,0,0,0.35)";
    ctx.strokeStyle = currentMap.accent || "#888";
    ctx.lineWidth = 2;
    for (const o of currentMap.obstacles) {
      ctx.fillRect(o.x, o.y, o.w, o.h);
      ctx.strokeRect(o.x, o.y, o.w, o.h);
    }

    // tracers
    ctx.strokeStyle = "rgba(255,220,140,0.85)";
    ctx.lineWidth = 2;
    tracers = tracers.filter((t) => t.life > 0);
    for (const t of tracers) {
      ctx.globalAlpha = t.life;
      ctx.beginPath(); ctx.moveTo(t.x1, t.y1); ctx.lineTo(t.x2, t.y2); ctx.stroke();
      t.life -= 0.15;
    }
    ctx.globalAlpha = 1;

    // other players
    for (const p of remotePlayers.values()) {
      if (p.id === selfId || !p.alive) continue;
      drawPlayer(p.x, p.y, p.angle, p.name, p.hp, "#e6534a");
    }
    // self
    if (self.alive) drawPlayer(self.x, self.y, self.angle, "you", self.hp, "#5ac8fa");

    ctx.restore();
    ctx.restore();

    updateHud();
  }

  function drawPlayer(x, y, angle, name, hp, color) {
    ctx.save();
    ctx.translate(x, y);
    // body
    ctx.fillStyle = color;
    ctx.beginPath(); ctx.arc(0, 0, 18, 0, Math.PI * 2); ctx.fill();
    // facing indicator
    ctx.rotate(angle);
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.fillRect(14, -3, 16, 6);
    ctx.restore();

    // name + health
    ctx.save();
    ctx.translate(x, y);
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.fillRect(-24, -38, 48, 6);
    ctx.fillStyle = hp > 40 ? "#6fcf7f" : "#e6534a";
    ctx.fillRect(-24, -38, 48 * Math.max(0, hp) / 100, 6);
    ctx.fillStyle = "#dfe6ee";
    ctx.font = "12px 'Share Tech Mono', monospace";
    ctx.textAlign = "center";
    ctx.fillText(name, 0, -44);
    ctx.restore();
  }

  function updateHud() {
    const remainMs = Math.max(0, roundEndAt - Date.now());
    const mm = Math.floor(remainMs / 60000);
    const ss = Math.floor((remainMs % 60000) / 1000);
    hudTimer.textContent = `${mm}:${String(ss).padStart(2, "0")}`;

    hudHealthFill.style.width = `${Math.max(0, self.hp)}%`;
    hudHealthLabel.textContent = Math.max(0, Math.round(self.hp));

    const w = WEAPONS[self.weapon] || WEAPONS.rifle;
    hudWeaponName.textContent = reloading ? `${w.name} (RELOADING)` : w.name;
    const ammoLeft = ammoLocal[self.weapon] ?? w.mag;
    hudAmmoCount.textContent = `${ammoLeft} / ${w.mag}`;
  }

  // ---------- Boot ----------
  applyControlVisibility();
  initMenu();
  resizeCanvas();
  connect();
  requestAnimationFrame(tick);
})();
