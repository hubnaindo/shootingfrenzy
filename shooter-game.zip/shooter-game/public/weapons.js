// Shared between server (Node require) and client (<script> tag).
// fireRate/reloadTime in ms. range in world units. spread in radians (half-angle).

const WEAPONS = {
  rifle: {
    id: "rifle", name: "AR-15 Rifle", slot: "primary",
    damage: 18, fireRate: 130, range: 700, spread: 0.045,
    mag: 30, reloadTime: 1700, pellets: 1, auto: true,
  },
  smg: {
    id: "smg", name: "Viper SMG", slot: "primary",
    damage: 12, fireRate: 85, range: 420, spread: 0.09,
    mag: 25, reloadTime: 1400, pellets: 1, auto: true,
  },
  shotgun: {
    id: "shotgun", name: "Trench Shotgun", slot: "primary",
    damage: 9, fireRate: 700, range: 260, spread: 0.22,
    mag: 6, reloadTime: 2000, pellets: 8, auto: false,
  },
  pistol: {
    id: "pistol", name: "M9 Pistol", slot: "secondary",
    damage: 20, fireRate: 260, range: 380, spread: 0.035,
    mag: 12, reloadTime: 1100, pellets: 1, auto: false,
  },
  revolver: {
    id: "revolver", name: ".44 Revolver", slot: "secondary",
    damage: 38, fireRate: 520, range: 500, spread: 0.018,
    mag: 6, reloadTime: 1500, pellets: 1, auto: false,
  },
};

const PRIMARY_CHOICES = ["rifle", "smg", "shotgun"];
const SECONDARY_CHOICES = ["pistol", "revolver"];

if (typeof module !== "undefined") module.exports = { WEAPONS, PRIMARY_CHOICES, SECONDARY_CHOICES };
